The official package of gRPC Python is `grpcio <https://pypi.org/project/grpcio/>`_.
Please download that package instead.